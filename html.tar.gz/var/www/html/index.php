<?php
header( "refresh:0;url=pages/index.php" );
?>
