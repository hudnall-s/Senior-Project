<?php 
//logout script
require_once'../scripts/sessions.php';

SessionStop();



?>