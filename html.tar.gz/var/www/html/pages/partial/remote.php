<?php
set_time_limit(0);
require_once("../includes/curl.php");
require_once("../scripts/sessions.php");
	class Remote{
		
     private $authString ="";
     private $userString = "";
     
     
     function __construct(){
       $this->userString = "UserId:" . $_SESSION['id'];
       $this->authString = "Authentication:" . $_SESSION['authString'];
     }
     
     public function auth()
     {
       $arr = Array();
       $arr[] = $this->authString;
       $arr[] = $this->userString;
       return $arr;
     }
     public function pressButton($remote, $button){
     
       $buttonLink = "http://127.0.0.1:8080/RemoteControl/rest/lirc/" . $remote
          . "/mappings";
       
       $curl = new Curl();
       $arr = Array();
       $arr[] = $this->userString;
       $arr[] = $this->authString;
       $buttonArr = $curl->getRequest2($buttonLink, "" );
       $buttonJson = json_decode($buttonArr, true);
       $buttonSend = "";
       foreach($buttonJson as $btn)
         {
          
           if ($btn["myHashMap"]["Key"] == $button)
           {
             $buttonSend = $btn["myHashMap"]["Command"]; 
             break;
           }
         }
      // var_dump($buttonSend);
       $foundButton = $buttonSend;
        $link = "http://127.0.0.1:8080/RemoteControl/rest/lirc/".
           $remote . "/" . $foundButton;
           
     //  var_dump($link);
       $buttonArr = $curl->getRequest2($link, $arr );
     //  var_dump($buttonArr);
       if ($buttonArr != "Sent")
         return "Failed to Send. Check Configuration";
       return $buttonArr;
     }
     

     private function sendCommand($remote, $button)
     {
        $curl = new Curl(); $curl = new Curl();
        $arr = $this->auth();
      
        $link = "http://127.0.0.1:8080/RemoteControl/rest/lirc/".
           $remote . "/" . $button;
     //  var_dump($link);
       $buttonArr = $curl->getRequest2($link, $arr );
     //  var_dump($buttonArr);
       return $buttonArr;
     
     }
     
     
     public function getMacros(){
       $link = "http://127.0.0.1:8080/RemoteControl/rest/Users/macros/";
       $link = $link . $_SESSION['id'] ;
       $curl = new Curl();
       $arr = Array("Authentication: " . $_SESSION['authString']);
       $remotes = $curl->getRequest2($link, $arr );
       return json_decode($remotes, true);
     }
     
     
     public function printMacros(){
       $macros = $this->getMacros();
       //var_dump($macros);
       $list = array();
       foreach ($macros as $m)
       {
           // foreach macro / append macro # to dropdown
           array_push($list, $m['macroId']);
       }
       $list = array_unique($list);
       echo <<< EOL
       
       <select name="macroSelect" id="macroSelect">
        <option selected="selected" value=0>Choose a Macro</option> 
        
EOL;
       foreach ($list as $l)
       {
        ?>
       
       <option value="<?php echo $l; ?>"><?php echo "MACRO #: " . $l ; ?></option>
          <?php
       }
         echo <<< EOL
       </select>
       <button type="button" class="btn btn-secondary" name="RunMacro">Run Macro</button>
EOL;
     }
     
     public function printMacros2(){
       $macros = $this->getMacros();
       //var_dump($macros);
       $list = array();
       foreach ($macros as $m)
       {
           // foreach macro / append macro # to dropdown
           array_push($list, $m['macroId']);
       }
       $list = array_unique($list);
       echo <<< EOL
       
       <select name="macroSelect" id="macroSelect">
        <option selected="selected" value=0>Choose a Macro</option> 
        
EOL;
        $max = 0;
       foreach ($list as $l)
       {
        ?>
       
       <option value="<?php echo $l; ?>"><?php echo "MACRO #: " . $l ; ?></option>
          <?php
          $max = $l;
       }
       
        ?>
        
         <option value="<?php echo $max + 1; ?>"> New Macro</option> 
       </select>
       <?php

     }
     public function addMacro($macro) {
     
     }
     
     // $data = Array("remote" => "epson_xxx");
     public function addFavorites($data){
       $link = "http://127.0.0.1:8080/RemoteControl/rest/Users/". $_SESSION['id'] 
           ."/favorites";
       $curl = new Curl();
       $arr = Array($this->authString, $this->userString);
       $arr[] = 'Content-Type:application/json';
       $add = $curl->putRequest2($link, $arr, $data);
       return $add;
     }
     
     
     public function getFavorites(){
       $link = "http://127.0.0.1:8080/RemoteControl/rest/Users/";
       $link = $link . $_SESSION['id'] . "/favorites"; 
       $curl = new Curl();
       $arr = Array("Authentication: " . $_SESSION['authString']);
       $remotes = $curl->getRequest2($link, "" );
       return json_decode($remotes, true);
     }
     public function printFavorites(){
       $favorites = $this->getFavorites();
       //var_dump($favorites);
       $list = array();
       foreach ($favorites as $f)
       {
           // foreach macro / append Favorite to dropdown
           array_push($list, $f['Remote']);
       }
       $list = array_unique($list);
       echo <<< EOL
       
       <select name="favoritesSelect" id="favoritesSelect">
        <option selected="selected" value=0>Choose a Favorite</option> 
        
EOL;
       foreach ($list as $l)
       {
        ?>
       
       <option value="<?php echo $l; ?>"><?php echo "Favorite: " . $l ; ?></option>
          <?php
       }
         echo <<< EOL
       </select>
       <button type="button" class="btn btn-secondary" name="LoadFavorite">Load Favorite</button>
EOL;
     }
     public function runMacro($id){
       ///macros/{id}/{macroId}
       $link = "http://127.0.0.1:8080/RemoteControl/rest/Users/macros/";
       $link = $link . $_SESSION['id'] . "/" . $id;
       $curl = new Curl();
       $arr = $this->auth();
       $macroCommands = json_decode($curl->getRequest2($link, $arr ), true);
       
       foreach ($macroCommands as $macro)
         {
           $command = $macro["command"];
           $remote  = $macro["remote"];
           sleep(1);
           
           echo $this->pressButton($remote,$command). " " . $command;
           echo "<br>";
           
         } 
     }
    
		 public function getRemoteBrands(){
       $link = "http://127.0.0.1:8080/RemoteControl/rest/lirc/remotes";
       $curl = new Curl();
       $remotes = $curl->getRequest2($link, "");
       $remotes = explode("[", $remotes);
       $remotes = explode(']', $remotes[1]);
       $remotes = explode(',', $remotes[0]);
      // var_dump($remotes);
       foreach($remotes as $r)
       {
       ?>
          <option value="<?php echo strtolower($r); ?>"><?php echo explode('"', $r)[1]; ?></option>
       <?php 
       }
}
		function printRemote(){
			echo <<<EOL
<div>			
<table class="table">
  <tr class="row">
    <td class="col-sm-1"> <button type="button" class="btn btn-secondary" name="Input" >Input </button>  </td>
    <td class="col-sm-1"></td>
    <td class="col-sm-1"> <button type="button" class="btn btn-Danger" name="Power">Power</button></td>
  </tr>
  <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="1">1</button> </td>
    <td><button type="button" class="btn btn-secondary" name="2">2</button> </td>
    <td><button type="button" class="btn btn-secondary" name="3">3</button> </td>
  </tr>
  <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="4">4</button> </td>
    <td><button type="button" class="btn btn-secondary" name="5">5</button> </td>
    <td><button type="button" class="btn btn-secondary" name="6">6</button> </td>
  </tr >
  <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="7">7</button> </td>
    <td><button type="button" class="btn btn-secondary" name="8">8</button> </td>
    <td><button type="button" class="btn btn-secondary" name="9">9</button> </td>
  </tr>
  <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="ESC">ESC</button> </td>
    <td><button type="button" class="btn btn-secondary" name="0">0</button> </td>
    <td><button type="button" class="btn btn-secondary" name="MENU">MENU</button> </td>
  </tr>
  <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="VOLUP">&nbsp;&nbsp;&nbsp;VOL UP &nbsp;&nbsp;&nbsp;</button> </td>
    <td></td>
    <td><button type="button" class="btn btn-secondary" name="CHUP">&nbsp;&nbsp;&nbsp;CH UP&nbsp;&nbsp;&nbsp;</button> </td>
  </tr>
   <tr class="row">
    <td><button type="button" class="btn btn-secondary" name="VOLDOWN">VOL DOWN</button> </td>
    <td><button type="button" class="btn btn-secondary" name="UP">UP</button> </td>
    <td><button type="button" class="btn btn-secondary" name="CHDOWN">CH DOWN</button> </td>
  </tr>
   <tr class="row">
   
    <td><button type="button" class="btn btn-secondary" name="LEFT">LEFT</button> </td>
	<td><button type="button" class="btn btn-secondary" name="ENTER">ENTER</button> </td>
	<td><button type="button" class="btn btn-secondary" name="RIGHT">RIGHT</button> </td>
  </tr>
    </tr>
   <tr class="row">
	<td></td>
	<td><button type="button" class="btn btn-secondary" name="DOWN">DOWN</button> </td>
	<td></td>
  </tr>
 
</table>
</div>
<div>
<center>
<select name="remoteSelect" id="remoteSelect">
        <option selected="selected">Choose a Remote</option> 
EOL;

  $this->getRemoteBrands();
  //var_dump($this->getMacros());
  //$this->getFavorites();
 // $this->pressButton("Epson_12807990", "PWR_ON");
  //  $this->runMacro(5);
  echo <<<EOL
  </select>
  <button type="button" class="btn btn-secondary" name="SaveFavorite">Save to Favorite</button>
  </center>
  
</div>
EOL;


		}
	}

?>




