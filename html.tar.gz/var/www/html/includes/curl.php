<?php 
class curl{

  function getRequest($link, $headerArray)
  {
    $curl_h = curl_init($link);

    curl_setopt($curl_h, CURLOPT_HTTPHEADER,
      $headerArray
    );

    # do not output, but store to variable
    curl_setopt($curl_h, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($curl_h);
    curl_close($curl_h);
    if ($response == "Found Password")
    {
      return true;
    }
    else
    {
      return false;
    }
  
  }
function getRequest2($link, $headerArray)
  {
    $curl_h = curl_init($link);

    curl_setopt($curl_h, CURLOPT_HTTPHEADER,
      $headerArray
    );

    # do not output, but store to variable
    curl_setopt($curl_h, CURLOPT_RETURNTRANSFER, true);
    

    $response = curl_exec($curl_h);
    curl_close($curl_h);
    return $response;
  
  }
  
function putRequest2($link, $headerArray, $data)
{
  $curl_h = curl_init($link);
  curl_setopt($curl_h, CURLOPT_HTTPHEADER,
      $headerArray
    );
    
  curl_setopt($curl_h, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl_h, CURLOPT_CUSTOMREQUEST, "PUT");
  curl_setopt($curl_h, CURLOPT_POSTFIELDS,$data);
  
  $response = curl_exec($curl_h);
  curl_close($curl_h);
  return $response;

}

function putRequest($link, $headerArray, $data)
{
  $curl_h = curl_init($link);
  curl_setopt($curl_h, CURLOPT_HTTPHEADER,
      $headerArray
    );
  var_dump(http_build_query($data));
  curl_setopt($curl_h, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl_h, CURLOPT_CUSTOMREQUEST, "PUT");
  curl_setopt($curl_h, CURLOPT_POSTFIELDS,http_build_query($data));
  
  $response = curl_exec($curl_h);
  curl_close($curl_h);
  return $response;

}

}
?>