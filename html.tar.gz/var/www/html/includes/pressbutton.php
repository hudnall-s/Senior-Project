<?php
  require_once("../pages/partial/remote.php");
  if($_POST['buttonpressed'])
  {
    $val = $_POST['buttonpressed'];
    $remoteline = $_POST['selectedRemote'];
    $remote = new Remote();
    print $remote->pressButton($remoteline, $val);
  }
  else if ($_POST['RunMacro'])
  {
    $val = $_POST['RunMacro'];
    $remote = new Remote();
    print $remote->runMacro($val);
  }
  else if ($_POST['SaveFavorite'])
  {
    $val = $_POST['SaveFavorite'];
    $remote = new Remote();
    $data = array ( "remote" => $val);
    $data = json_encode($data);
    print $remote->addFavorites($data);
  }
  
?>