$("button").click(function() { 
      var buttonpressed = $(this).attr('name');
      var e = document.getElementById("remoteSelect");
      var selectedRemote = e.options[e.selectedIndex].text;
      var textarea = document.getElementById("exampleFormControlTextarea2");
      var m = document.getElementById("macroSelect");
      var RunMacro = m.options[m.selectedIndex].value;
      if (buttonpressed == "SaveMacro" && RunMacro != 0)
      {
         
          var setStuff = textarea.value; 
          var setStuff = setStuff.slice(0, -1);
          $.ajax({
          url: '/pages/setstuff.php',
          method : 'POST',
          async : false,
          data: {setStuff :  (setStuff || ''), RunMacro: (RunMacro || '')},
          success : function(data) {
              textarea.value = "";
            },
          error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
        },  
      });
      textarea.value = "";  
      }
      
      else if (selectedRemote != "Choose a Remote")
      {  
        textarea.value += selectedRemote;
        textarea.value += ":";
        textarea.value += buttonpressed;
        textarea.value += ",";
      }
}); 