
$("button").click(function() { 
      var buttonpressed = $(this).attr('name');
      var e = document.getElementById("remoteSelect");
      var selectedRemote = e.options[e.selectedIndex].text;
      if (buttonpressed == "LoadFavorite")
      {
        var f = document.getElementById("favoritesSelect");
        
        e.options[e.selectedIndex].text = f.options[f.selectedIndex].value;
        e.options[e.selectedIndex].value = f.options[f.selectedIndex].value;
      }
      else if (buttonpressed == "SaveFavorite")
      {
      
          var SaveFavorite = selectedRemote;
          $.ajax({
          url: '/includes/pressbutton.php',
          method : 'POST',
          async : false,
          data: {SaveFavorite :  (SaveFavorite || '')},
          success : function(data) {
              alert("Saved Remote To Favorite");
            },
          error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
          alert(msg);
        },    
      });
      }
      else if (buttonpressed == "RunMacro" )
      {
          alert("running macro");
          var m = document.getElementById("macroSelect");
          var RunMacro = m.options[m.selectedIndex].value;
          $.ajax({
          url: '/includes/pressbutton.php',
          method : 'POST',
          async : false,
          data: {RunMacro :  (RunMacro || '')},
          success : function(data) {
              alert(data);
            },
          error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
          alert(msg);
        },    
      });
          
      }
      
      else
      {
      $.ajax({
          url: '/includes/pressbutton.php',
          method : 'POST',
          async : false,
          data: {buttonpressed :  (buttonpressed || '' ), selectedRemote : (selectedRemote || '')},
          success : function(data) {
              alert(data);
            },
          error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
          alert(msg);
        },    
      });
      }
   });
